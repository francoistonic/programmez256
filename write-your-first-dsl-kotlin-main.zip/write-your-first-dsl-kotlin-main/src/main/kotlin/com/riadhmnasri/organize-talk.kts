organize talk {
    assign name "Write your first DSL"
    starts at 16..30
    ends at 17..15
    speakers include "Riadh" and "Romain"
    participants include "Dimitri" and "Cyril" and "Mohamed" and "Sonia" and "Isabelle"
}






kotlinc-jvm -d talk.jar talk.kt
kotlinc-jvm -classpath talk.jar -script organize-talk.kts

kotlinc-jvm -d conference.jar conferenceDslMarker.kt
kotlinc-jvm -classpath conference.jar -script conference.kts

build {
  conferenceName = "Dev Conf 100% Kotlin"

  keyword("kotlin")
  keyword("dsl")

  talk("Write your first DSL with Kotlin !") {
    talkName = "Talk Name changed"

    //talk("**should.not.be.here**")
  }
}




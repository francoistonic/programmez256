# Functional Programming with Kotlin and ArrowKT


